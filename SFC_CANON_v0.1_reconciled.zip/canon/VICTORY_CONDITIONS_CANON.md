# VICTORY_CONDITIONS_CANON
_Status: LOCKED (v0.1 Reconciled)_

## Shadow Victory — Regional Corruption
Shadow wins when **5 regions** are **fully corrupted**.

## Dominion Victory
Any player wins at End of Round if they control all **5 Dominion Regions**:
- The Shire
- Rivendell
- Lothlórien
- Rohan
- Gondor

## Ring Victory — Ring Peace (Any uncorrupted Hero)
An uncorrupted Hero bearing **The One Ring** wins at End of Round if they control **3 uncorrupted regions** simultaneously.

## Ring Victory — Ring Destruction (Frodo only)
Only Frodo can destroy the Ring.
Requirements:
- Frodo is in Mordor
- “Mount Doom” requirement is satisfied in the PWA (card/condition)
- Frodo has **0 corruption**
- Frodo survives **two full rounds**

## Rare Shadow Victory — Corrupted Saruman + The One Ring
- The One Ring may be equipped/used by any player.
- If the Ring-bearer is destroyed, the Ring is reshuffled into the Universal Deck.
- If a **player-controlled Corrupted Saruman** defeats a Ring-bearer, the game ends immediately: Saruman’s controller wins.
- Non-player-controlled Saruman cannot claim this win.

END OF VICTORY_CONDITIONS_CANON (LOCKED)
