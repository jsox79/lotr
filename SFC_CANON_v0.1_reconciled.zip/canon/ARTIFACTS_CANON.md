# ARTIFACTS_CANON
_Status: FINAL (v0.1 Playtest)_
_Total Artifacts: 16_

This document defines all Artifact cards included in the Universal Deck
for the initial full-game playtest.

Artifacts enhance Heroes but do not replace them as the primary drivers of play.
Only the One Ring enables alternate victory paths.

---

## ARTIFACT RARITY TIERS

Artifacts are divided into three tiers:
- Common (8)
- Rare (6)
- Legendary (2)

Rarity affects:
- draw frequency
- power level
- corruption pressure
- narrative weight

---

## 🟢 COMMON ARTIFACTS (8)

Utility-focused, low corruption impact, widely usable.

---

### Elven Cloak
Artifact — Common  
Stealth, evasion, and protection effects.  
Low-risk, high-utility.

---

### Sting
Artifact — Common  
A blade that warns of nearby enemies.  
Grants minor combat bonuses, especially against Enemies.  
No corruption effects.

---

### Dwarven Mail
Artifact — Common  
Grants +Health or damage mitigation.  
Purely defensive.

---

### Phial of Light
Artifact — Common  
One-time or limited Shadow disruption.  
Strong against Nazgûl or darkness effects.

---

### Horn of Rohan
Artifact — Common  
Allows rallying or readying Allies.  
Supports mobility and counterattacks.

---

### Ranger’s Blade
Artifact — Common  
Generic combat enhancement for Heroes.  
Reliable but unremarkable.

---

### Ancient Map
Artifact — Common  
Provides movement, scouting, or region awareness benefits.  
Encourages exploration.

---

### Healing Draught
Artifact — Common  
One-time healing effect.  
Keeps Heroes alive without removing long-term danger.

---

## 🔵 RARE ARTIFACTS (6)

Powerful, tempting, often tied to corruption risk or strategic swings.

---

### Narya — Ring of Fire
Artifact — Rare  
Associated with Gandalf.  
Inspires Allies and strengthens resistance.  
Introduces gradual corruption risk over time.

---

### Nenya — Ring of Adamant
Artifact — Rare  
Associated with Galadriel.  
Prevents or slows corruption in regions.  
Extended use invites Shadow attention.

---

### Dwarven Ring of Power
Artifact — Rare  
Improves durability, wealth, or region control.  
Accelerates Dominion strategies.  
Slowly increases corruption.

---

### Glamdring — Foe-Hammer
Artifact — Rare  
Elite enemy slayer.  
Strong combat spike against powerful Enemies.

---

### Orcrist — Goblin Cleaver
Artifact — Rare  
Extra effectiveness against common Enemies.  
Encourages aggressive play.

---

### Palantír
Artifact — Rare  
Allows deck inspection, information control, or manipulation.  
Heavy corruption risk.

---

## 🟣 LEGENDARY ARTIFACTS (2)

Game-defining artifacts with major narrative and mechanical weight.

---

### The One Ring
Artifact — Legendary  

- Enables Ring Peace and Ring Destruction victory paths.
- Generates corruption rapidly.
- Subject to Gollum disruption (3 copies in deck).

This is the single most dangerous artifact in the game.

---

### Morgul Blade
Artifact — Legendary  

- Massive combat threat.
- Rapidly corrupts Heroes.
- Enables Shadow-aligned character victories.
- Not a direct win condition, but a terrifying accelerant.

---

## DESIGN INTENT (LOCKED)

- Artifacts support Heroes; they do not replace them.
- Rings of Power are **Rare**, not Legendary.
- The One Ring remains unique in both power and danger.
- If players focus more on artifacts than Heroes, balance must be adjusted.

---

END OF ARTIFACTS_CANON (FINAL)
