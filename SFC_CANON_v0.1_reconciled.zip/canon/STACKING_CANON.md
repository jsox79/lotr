# STACKING_CANON
_Status: LOCKED (v0.1 Reconciled)_

- Each player has exactly ONE Active Hero.
- Players may control additional Heroes as Bannermen (supporting Heroes).
- Armies/Allies, Titles/Boons, Artifacts, and other stack pieces may stack without artificial caps.
- Natural guardrails apply: if the stack’s Hero is defeated/destroyed, the stack collapses and stacked cards are lost/discharged per PWA rules.

END OF STACKING_CANON (LOCKED)
