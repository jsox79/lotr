# HERO_FACTION_MAPPING_CANON
_Status: LOCKED (v0.1 Reconciled)_

Starting Regions are authoritative in CHARACTER_VALUES_CANON.

Factions (v0.1):
- The Shire
- Elves of the West
- Gondor
- Rohan
- Dwarves of the Mountain
- Isengard
- Wild/Neutral (Fangorn)

END OF HERO_FACTION_MAPPING_CANON (LOCKED)
