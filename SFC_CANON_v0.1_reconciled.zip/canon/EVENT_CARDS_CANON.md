# EVENT_CARDS_CANON
_Status: LOCKED (v0.1 Reconciled)_
_Source: EVENT_CARDS_CANON.md (philosophy) + EVENT_CARDS_V0.1_CANON.md (exact list)_

---

## A) Philosophy & Taxonomy (Authoritative)

# EVENT_CARDS_CANON
_Status: FINAL_
_Last updated: current session_

This document defines Event cards: their taxonomy, intent, timing,
and representative examples.

Event cards are drawn from the **Universal Deck** and represent
major historical moments, sudden turns of fate, and narrative disruptions.

Event cards are intentionally disruptive.
They exist to prevent uniform, solved play.

---

## EVENT CARD PHILOSOPHY

Event cards:
- Break symmetry
- Disrupt optimal lines
- Force adaptation
- Advance narrative pressure

They should:
- Never feel trivial
- Never feel purely punitive
- Always force a decision or consequence

The PWA tracks:
- timing
- duration
- region targeting
- once-per-round or once-per-game limits

---

## EVENT CARD TIMING

Unless otherwise specified, Event cards resolve:
- Immediately when played
- Or at the start of the next relevant phase (noted on the card)

No Event may cause:
- Mid-round victory
- Mid-round region control lock
- Mid-round corruption finalization

All permanent outcomes are confirmed **end of round**.

---

## EVENT CARD TAXONOMY

Event cards are grouped by **functional role**, not by faction.

---

## I. GLOBAL EVENTS

Affect the entire board or all players.

### Example: *The Shadow Lengthens*
Type: Global Event  

Effect:
- Each region gains 1 Corruption.
- Regions with a Hero present may prevent this by discarding 1 card.

Design Intent:
- Late-game pressure
- Punishes hoarding
- Speeds endgame

---

### Example: *The West Stirs*
Type: Global Event  

Effect:
- Each player may ready one exhausted Hero or Ally.
- Then draw 1 card.

Design Intent:
- Momentum swing
- Encourages engagement

---

## II. REGIONAL EVENTS

Target one or more Greater Regions.

### Example: *The Battle of Helm’s Deep*
Type: Regional Event (Rohan)  

Effect:
- In Rohan:
  - Allies gain +2 Strength this round.
  - If Rohan is uncorrupted at end of round, prevent 1 Corruption there.

Design Intent:
- Region spotlight
- Narrative payoff
- Defensive anchor

---

### Example: *Siege of Gondor*
Type: Regional Event (Gondor)  

Effect:
- Gondor gains 2 Corruption.
- Heroes in Gondor may suffer 1 Damage to prevent 1 Corruption.

Design Intent:
- Despair tension
- Heroic sacrifice moment

---

## III. HERO-CENTRIC EVENTS

Target specific Heroes or Hero types.

### Example: *The Temptation of the Ring*
Type: Hero Event  

Effect:
- A Hero bearing the One Ring must choose:
  - Gain 2 Corruption
  - Or discard the Ring

Design Intent:
- Ring pressure
- No “free” Ring usage

---

### Example: *A Light in Dark Places*
Type: Hero Event  

Effect:
- Choose a Hero:
  - Heal all Damage
  - Prevent all Corruption this round

Design Intent:
- Comeback valve
- Rare relief moment

---

## IV. SHADOW ESCALATION EVENTS

Accelerate corruption or enemy pressure.

### Example: *The Nazgûl Ride*
Type: Shadow Event  

Effect:
- Place an Enemy in each region adjacent to Mordor.
- Those regions gain +1 Corruption at end of round.

Design Intent:
- Board compression
- Shadow inevitability

---

### Example: *Industry Without Mercy*
Type: Shadow Event  

Effect:
- Isengard and adjacent regions gain 1 Corruption.
- Fangorn may immediately retaliate (if controlled by Treebeard).

Design Intent:
- Saruman vs Fangorn tension
- High-risk escalation

---

## V. FACTION-INTERACTION EVENTS

Force political or factional choices.

### Example: *The Council Is Divided*
Type: Faction Event  

Effect:
- Choose one:
  - Draw 2 cards
  - Prevent 1 Corruption in any region
- If White Council is in play, both effects occur.

Design Intent:
- Political leverage
- Faction identity reinforcement

---

### Example: *Oaths Fulfilled*
Type: Faction Event  

Effect:
- If Aragorn is in play:
  - Gain control of one adjacent region this round.
- Otherwise:
  - Draw 1 card.

Design Intent:
- Conditional power
- Rewards narrative alignment

---

## VI. CHAOS / WILD EVENTS

Unpredictable but bounded effects.

### Example: *The World Is Changed*
Type: Wild Event  

Effect:
- Shuffle the discard pile into the Universal Deck.
- Draw 1 card.

Design Intent:
- Reset entropy
- Prevent deck exhaustion predictability

---

### Example: *Rumors and Whispers*
Type: Wild Event  

Effect:
- Look at the top 3 cards of the Universal Deck.
- Discard 1, reorder the rest.

Design Intent:
- Information warfare
- PWA-supported secrecy

---

## EVENT CARD FREQUENCY (GUIDELINE)

Recommended distribution in Universal Deck:
- ~25–30% Events
- Mix weighted toward:
  - Regional
  - Hero-centric
  - Shadow escalation
- Fewer global hard resets

Events should be:
- common enough to matter
- rare enough to feel significant

---

## DESIGN NORTH STAR

Event cards should make players say:
> “Well… now we have to deal with *this*.”

If an Event is ignored, it failed.
If an Event ends the game instantly, it failed.

---

## GOLLUM (SPECIAL CARD)

Card Type: Special — Unique Disruption  
Deck: Universal Deck  
Copies: 3  

When Gollum is drawn or played:

- If the One Ring is:
  - attached to a Hero, or
  - in any player’s hand,
  the One Ring is immediately removed and shuffled back into the Universal Deck.

- This effect cannot be prevented or redirected.

After resolving this effect:
- Discard Gollum unless otherwise specified by a card or scenario.

Design Notes:
- Gollum represents obsession, loss, and inevitability.
- He exists to destabilize Ring strategies without handing the Ring directly to Shadow.
- Multiple copies ensure the Ring is never fully safe.

"If the Ring is found, it will be lost."


END OF EVENT_CARDS_CANON (FINAL)

---

## B) v0.1 Exact Event List (27 cards) (Authoritative)

# EVENT_CARDS_V0.1_CANON
_Status: FINAL (Playtest v0.1)_
_Total Event Cards: 27_

This document defines the exact Event cards included in the
Universal Deck for the first full game + PWA playtest.

Events are disruptive by design and resolve via the Companion PWA.
No Event causes mid-round victory or permanent resolution outside
End of Round.

---

## I. GLOBAL EVENTS (5)

High-impact, table-wide pressure or relief.

---

### The Shadow Lengthens
Each Greater Region gains 1 Corruption.
Heroes may discard 1 card to prevent this in their region.

---

### The West Stirs
Each player may ready one exhausted Hero or Ally.
Then each player draws 1 card.

---

### Dark Tidings
Each player discards 1 card.
If a player has no cards, they gain 1 Corruption instead.

---

### The World Is Changed
Shuffle the discard pile into the Universal Deck.
Then draw 1 card.

---

### Hope Fades
Until end of round, Corruption cannot be removed by Event cards.

---

## II. REGIONAL EVENTS (9)

Spotlight specific Greater Regions and force local conflict.

---

### The Battle of Helm’s Deep (Rohan)
Allies in Rohan gain +2 Strength this round.
If Rohan is uncorrupted at end of round, prevent 1 Corruption there.

---

### Siege of Gondor (Gondor)
Add 2 Corruption to Gondor.
Heroes there may suffer 1 Damage to prevent 1 Corruption.

---

### Shadows in Mirkwood (Mirkwood)
Place an Enemy in Mirkwood.
That Enemy gains +1 Strength this round.

---

### The White Tree Withers (Gondor)
If Gondor is corrupted, add 1 additional Corruption.
Otherwise, draw 1 card.

---

### Lórien Stands Fast (Lothlórien)
Remove 1 Corruption from Lothlórien.
Heroes there cannot gain Corruption this round.

---

### The Watcher in the Water (Rivendell Adjacent)
The next Hero to enter Rivendell suffers 2 Damage.

---

### Smoke Rises from Isengard (Isengard)
Add 1 Corruption to Isengard and all adjacent regions.

---

### The East Stirs (Erebor)
If Erebor is controlled, draw 2 cards.
Otherwise, add 1 Corruption to Erebor.

---

### Fangorn Awakens (Fangorn)
If Fangorn is uncorrupted, destroy an Enemy there.
Otherwise, add 1 Corruption to Fangorn.

---

## III. HERO-CENTRIC EVENTS (6)

Target Heroes directly; test corruption, damage, and promotion logic.

---

### The Temptation of the Ring
A Hero bearing the One Ring must:
- gain 2 Corruption, or
- discard the Ring.

---

### A Light in Dark Places
Choose a Hero.
Heal all Damage on that Hero.
Prevent Corruption to that Hero this round.

---

### A Hero’s Fall
Deal 2 Damage to a Hero.
If that Hero is destroyed, draw 1 card.

---

### The Burden Grows Heavy
Choose a Hero.
That Hero gains 1 Corruption and is exhausted.

---

### Rally the Free Peoples
Choose a Hero.
Ready all Allies stacked with that Hero.

---

### A Choice of Mercy
Prevent the next Corruption placed on a Hero this round.
If prevented, draw 1 card.

---

## IV. SHADOW ESCALATION EVENTS (5)

Accelerate corruption and enemy presence.

---

### The Nazgûl Ride
Place an Enemy in each region adjacent to Mordor.
Those regions gain 1 Corruption at end of round.

---

### Industry Without Mercy
Add 1 Corruption to Isengard and one adjacent region.
If Fangorn is adjacent, Fangorn may retaliate (per PWA logic).

---

### The Dark Lord’s Eye
Look at the top 3 cards of the Universal Deck.
Reorder them.
Then add 1 Corruption to any region.

---

### Orcs Multiply
Place two Common Enemies in one region.
That region gains 1 Corruption.

---

### A Shadow Moves
Move one Enemy to an adjacent region.
That Enemy gains +1 Strength this round.

---

## V. WILD / CHAOS EVENTS (2)

Unpredictable but bounded disruption.

---

### Rumors and Whispers
Look at the top 3 cards of the Universal Deck.
Discard 1 and reorder the rest.

---

### Fate Intervenes
Cancel the effects of another Event card.
Draw 1 card.

---

## DESIGN INTENT (LOCKED)

- Events must force decisions.
- Events must never be ignorable.
- Events should expose balance problems quickly.
- If an Event feels boring, it should be replaced.

---

END OF EVENT_CARDS_V0.1_CANON

---

## C) Special Event Copies (Universal Deck)

### Gollum — x3 copies (Event)
When drawn:
- If **The One Ring** is in any player’s hand OR attached to any Hero: it must be **shuffled back into the Universal Deck**.

END OF EVENT_CARDS_CANON (LOCKED)
