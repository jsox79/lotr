# TITLES_BOONS_CANON
_Status: LOCKED (v0.1 Reconciled)_

Titles/Boons are represented as cards (often within ARTIFACTS_CANON for v0.1).
They exist to deepen stacking and reinforce narrative identity.
Effects/timing are resolved in the PWA and/or the relevant canon files.

END OF TITLES_BOONS_CANON (LOCKED)
