# REGIONS_CANON
_Status: LOCKED (v0.1 Reconciled)_

## Greater Regions (10)
1) The Shire
2) Rivendell
3) Lothlórien
4) Mirkwood
5) Rohan
6) Gondor
7) Isengard
8) Mordor
9) Erebor
10) Fangorn (Wild)

Notes:
- Fangorn is Wild/Neutral and does not grant a faction.

END OF REGIONS_CANON (LOCKED)
