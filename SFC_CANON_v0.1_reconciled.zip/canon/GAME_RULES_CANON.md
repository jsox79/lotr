# GAME_RULES_CANON
_Status: LOCKED (v0.1 Reconciled)_

Physical cards display:
- Name
- Strength (Str)
- Health (HP)

All passives, actions, corruption rules, and stack logic are enforced via the PWA.

## State Finalization
- Actions apply immediately.
- No outcome is final until the End of Round check completes (victory, corruption finalization, control locks).

END OF GAME_RULES_CANON (LOCKED)
