# Shadow & Fellowship — Canon v0.1 (Reconciled)

This folder is the single source of truth for Shadow & Fellowship tabletop rules + PWA companion.

Principles:
- Physical cards are minimal; most rules are resolved in the PWA.
- The Universal Deck contains all non-corrupted cards.
- Corrupted Hero cards are kept in a separate Corrupted Heroes deck.

Versioning:
- Any change requires bumping canon (v0.2, v0.3...) and regenerating this folder.
- Recommended storage: Git repo. Reference by commit hash.

LOCK STATUS: LOCKED
