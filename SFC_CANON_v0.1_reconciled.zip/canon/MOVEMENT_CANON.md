# MOVEMENT_CANON
_Status: LOCKED (v0.1 Reconciled)_

Movement is adjacency (movement graph) resolved in the PWA.
Default: 1 move per turn, modified by cards and region state.

END OF MOVEMENT_CANON (LOCKED)
