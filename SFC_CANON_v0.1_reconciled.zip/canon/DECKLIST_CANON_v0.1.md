# DECKLIST_CANON_v0.1
_Status: LOCKED_
_Universal Deck Total: 129_

## HEROES (20) — 1× each
(See CHARACTER_VALUES_CANON)
- Frodo Baggins
- Samwise Gamgee
- Merry Brandybuck
- Pippin Took
- Gandalf the Grey
- Elrond, Lord of Rivendell
- Galadriel (Draw-only)
- Aragorn, Heir of Isildur
- Boromir, Captain of Gondor
- Faramir, Captain of Ithilien
- Denethor, Steward of Gondor (Draw-only)
- Théoden, King of Rohan
- Éomer
- Éowyn
- Legolas
- Gimli, Son of Glóin
- Dáin Ironfoot
- Thorin Stonehelm
- Treebeard (Draw-only)
- Saruman the White (Draw-only)

## ARTIFACTS (16) — 1× each
(Exactly as defined in ARTIFACTS_CANON)

## EVENTS (30)
- Event list (27) as defined in EVENT_CARDS_CANON
- Plus: Gollum ×3

## LESSER LOCATIONS (11) — 1× each
(Exactly as defined in LESSER_LOCATIONS_CANON)

## ENEMIES & CREATURES (34) — 1× each
(As defined in ENEMIES_&_CREATURES_CANON; numeric targets in ENEMY_&_CREATURE_COUNTS_CANON)

## ALLIES (18) — 1× each
(Exactly as defined in ALLIES_CANON)

## UNIVERSAL DECK TOTAL
20 + 16 + 30 + 11 + 34 + 18 = 129

END OF DECKLIST_CANON_v0.1 (LOCKED)
