# SETUP_TURN_CANON
_Status: LOCKED (v0.1 Reconciled)_

## Setup
1) All players roll a d20 in the PWA.
2) Highest chooses Hero first; continue descending.
   - If needed: remaining players roll again to break ties for next pick order.
3) After choosing, place your starting Hero in their Starting Region (per CHARACTER_VALUES_CANON).
4) All non-chosen Heroes are shuffled into the Universal Deck as Supporting (Bannermen) Heroes.
5) Each player draws their starting hand (PWA-configurable; default: 5).

## Turn Order
- Play proceeds counterclockwise from Player 1.
- A “Round” completes when play returns to Player 1.

## Round Structure (PWA tracked)
1) Refresh
2) Planning
3) Journey
4) Conflict
5) Shadow Phase (End of Round)

END OF SETUP_TURN_CANON (LOCKED)
