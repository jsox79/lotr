# EVENT_CARDS_V0.1_CANON
_Status: FINAL (Playtest v0.1)_
_Total Event Cards: 27_

This document defines the exact Event cards included in the
Universal Deck for the first full game + PWA playtest.

Events are disruptive by design and resolve via the Companion PWA.
No Event causes mid-round victory or permanent resolution outside
End of Round.

---

## I. GLOBAL EVENTS (5)

High-impact, table-wide pressure or relief.

---

### The Shadow Lengthens
Each Greater Region gains 1 Corruption.
Heroes may discard 1 card to prevent this in their region.

---

### The West Stirs
Each player may ready one exhausted Hero or Ally.
Then each player draws 1 card.

---

### Dark Tidings
Each player discards 1 card.
If a player has no cards, they gain 1 Corruption instead.

---

### The World Is Changed
Shuffle the discard pile into the Universal Deck.
Then draw 1 card.

---

### Hope Fades
Until end of round, Corruption cannot be removed by Event cards.

---

## II. REGIONAL EVENTS (9)

Spotlight specific Greater Regions and force local conflict.

---

### The Battle of Helm’s Deep (Rohan)
Allies in Rohan gain +2 Strength this round.
If Rohan is uncorrupted at end of round, prevent 1 Corruption there.

---

### Siege of Gondor (Gondor)
Add 2 Corruption to Gondor.
Heroes there may suffer 1 Damage to prevent 1 Corruption.

---

### Shadows in Mirkwood (Mirkwood)
Place an Enemy in Mirkwood.
That Enemy gains +1 Strength this round.

---

### The White Tree Withers (Gondor)
If Gondor is corrupted, add 1 additional Corruption.
Otherwise, draw 1 card.

---

### Lórien Stands Fast (Lothlórien)
Remove 1 Corruption from Lothlórien.
Heroes there cannot gain Corruption this round.

---

### The Watcher in the Water (Rivendell Adjacent)
The next Hero to enter Rivendell suffers 2 Damage.

---

### Smoke Rises from Isengard (Isengard)
Add 1 Corruption to Isengard and all adjacent regions.

---

### The East Stirs (Erebor)
If Erebor is controlled, draw 2 cards.
Otherwise, add 1 Corruption to Erebor.

---

### Fangorn Awakens (Fangorn)
If Fangorn is uncorrupted, destroy an Enemy there.
Otherwise, add 1 Corruption to Fangorn.

---

## III. HERO-CENTRIC EVENTS (6)

Target Heroes directly; test corruption, damage, and promotion logic.

---

### The Temptation of the Ring
A Hero bearing the One Ring must:
- gain 2 Corruption, or
- discard the Ring.

---

### A Light in Dark Places
Choose a Hero.
Heal all Damage on that Hero.
Prevent Corruption to that Hero this round.

---

### A Hero’s Fall
Deal 2 Damage to a Hero.
If that Hero is destroyed, draw 1 card.

---

### The Burden Grows Heavy
Choose a Hero.
That Hero gains 1 Corruption and is exhausted.

---

### Rally the Free Peoples
Choose a Hero.
Ready all Allies stacked with that Hero.

---

### A Choice of Mercy
Prevent the next Corruption placed on a Hero this round.
If prevented, draw 1 card.

---

## IV. SHADOW ESCALATION EVENTS (5)

Accelerate corruption and enemy presence.

---

### The Nazgûl Ride
Place an Enemy in each region adjacent to Mordor.
Those regions gain 1 Corruption at end of round.

---

### Industry Without Mercy
Add 1 Corruption to Isengard and one adjacent region.
If Fangorn is adjacent, Fangorn may retaliate (per PWA logic).

---

### The Dark Lord’s Eye
Look at the top 3 cards of the Universal Deck.
Reorder them.
Then add 1 Corruption to any region.

---

### Orcs Multiply
Place two Common Enemies in one region.
That region gains 1 Corruption.

---

### A Shadow Moves
Move one Enemy to an adjacent region.
That Enemy gains +1 Strength this round.

---

## V. WILD / CHAOS EVENTS (2)

Unpredictable but bounded disruption.

---

### Rumors and Whispers
Look at the top 3 cards of the Universal Deck.
Discard 1 and reorder the rest.

---

### Fate Intervenes
Cancel the effects of another Event card.
Draw 1 card.

---

## DESIGN INTENT (LOCKED)

- Events must force decisions.
- Events must never be ignorable.
- Events should expose balance problems quickly.
- If an Event feels boring, it should be replaced.

---

END OF EVENT_CARDS_V0.1_CANON
