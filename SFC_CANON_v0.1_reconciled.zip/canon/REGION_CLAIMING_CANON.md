# REGION_CLAIMING_CANON
_Status: LOCKED (v0.1 Reconciled)_

Unoccupied regions may be claimed via PWA-defined checks.
v0.1 supports a d20 claim-check model; DCs/modifiers are configured per region in the PWA.

END OF REGION_CLAIMING_CANON (LOCKED)
