# ENEMIES_&_CREATURES_CANON
_Status: FINAL (subject to numeric tuning only)_
_Last updated: current session_

This document defines all Enemy and Creature cards.
Enemies are controlled by the Shadow system or player effects.
All abilities are implemented and tracked in the Companion PWA.

Physical Enemy cards (if printed) show:
- Name
- Strength
- Health

All rules text lives in the PWA.

---

## DESIGN PRINCIPLES

- Enemies are **pressure**, not puzzles.
- Creatures should force:
  - movement
  - stacking decisions
  - corruption tradeoffs
- Boss-level enemies should feel inevitable if ignored.
- Enemy strength benchmarks assume:
  - Heroes range from Str 1–6 uncorrupted
  - Corrupted heroes reach Str 7+

---

## ENEMY TIERS

- **Minor Enemies**: Delay, tax, harass
- **Major Enemies**: Anchor regions, force response
- **Legendary Creatures**: Warp the game state

---

## MINOR ENEMIES

### ORC WAR BAND
Enemy — Shadow  
Str 2 • HP 2  

Passive:
- While Orc War Band is in a region, that region gains +1 Corruption during the Shadow phase.

Notes:
- Baseline corruption pressure
- Weak alone, dangerous in numbers

---

### URUK-HAI SCOUTS
Enemy — Isengard  
Str 3 • HP 2  

Reaction:
- After Uruk-Hai Scouts enter a region, they may immediately move to an adjacent region.

Notes:
- Mobility pressure
- Enables Saruman strategies

---

### MORDOR SPY
Enemy — Shadow  
Str 1 • HP 1  

Passive:
- While Mordor Spy is in a region, players there cannot draw extra cards.

Notes:
- Information denial
- Extremely fragile

---

### HILL-MEN RAIDERS
Enemy — Shadow  
Str 2 • HP 3  

Reaction:
- After Hill-Men Raiders win combat, add 1 Corruption to the region.

Notes:
- Early regional corruption escalator

---

## MAJOR ENEMIES

### TROLL OF GORGOROTH
Creature — Shadow  
Str 5 • HP 6  

Passive:
- Troll of Gorgoroth ignores the first 1 Damage dealt to it each round.

Notes:
- Designed to require stacking heroes or corruption tradeoffs
- Strong mid-game blocker

---

### NAZGÛL, RINGWRAITH
Enemy — Shadow  
Str 4 • HP 4  

Passive:
- Heroes in this region gain +1 Corruption when they enter.

Reaction:
- When Nazgûl defeats a Hero, add 1 Corruption to that Hero.

Notes:
- Corruption accelerator
- Central to Ring pressure

---

### ISENGARD ENGINE
Enemy — Isengard  
Str 4 • HP 5  

Passive:
- At the start of each Shadow phase, add 1 Corruption to this region.

Notes:
- Region anchor
- Combos with Saruman and Fangorn tension

---

### SOUTHERLING WAR HOST
Enemy — Shadow  
Str 4 • HP 5  

Passive:
- Gains +1 Strength while attacking a region with Allies present.

Notes:
- Punishes ally-heavy strategies

---

## LEGENDARY CREATURES / BOSSES

### THE BALROG OF MORIA
Legendary Creature — Shadow  
Str 7 • HP 8  

Passive:
- Heroes cannot retreat from this region.

Reaction:
- When the Balrog defeats a Hero, destroy that Hero instead of dealing damage.

Notes:
- Endgame-level threat
- Designed to force sacrifice or avoidance
- Cannot be ignored

---

### SHELOB, GREAT SPIDER
Legendary Creature — Shadow  
Str 6 • HP 6  

Passive:
- Heroes in this region cannot use Actions.

Reaction:
- When Shelob deals Damage to a Hero, that Hero gains 1 Corruption.

Notes:
- Hard counter to ability-heavy heroes
- Frodo-specific narrative tension

---

### THE WATCHER IN THE WATER
Legendary Creature — Shadow  
Str 5 • HP 7  

Passive:
- Heroes cannot enter or leave this region unless they win a combat here.

Notes:
- Movement denial
- Region lockdown

---

## CORRUPTION SYNERGY RULES

- Enemies may add Corruption directly or indirectly.
- Enemies do NOT flip; they are destroyed when HP reaches 0.
- Some Enemies escalate if left alive across rounds.

---

## BALANCE NOTES (FOR YOU)

- Minor Enemies should fall to:
  - one Hero
  - or light stacking
- Major Enemies require:
  - multiple Heroes
  - or corruption acceptance
- Legendary Creatures are:
  - optional to defeat
  - but devastating if ignored

If a table allows two Legendary Creatures to persist, the game should be near its end.

---

END OF ENEMIES_&_CREATURES_CANON
