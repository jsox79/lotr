# CHARACTER_VALUES_CANON
Status: FINAL (v0.1)
Lock Date: 2026-01-23

This document is the single authoritative source for all character values,
abilities, corruption behavior, and setup eligibility.

Physical Hero cards display only:
- Name
- Strength (Str)
- Health (HP)

All other text is resolved via the PWA.

--------------------------------------------------
GLOBAL HERO RULES
--------------------------------------------------

• Each player has exactly ONE Active Hero at a time.
• Players may control additional Heroes as Bannermen (supporting Heroes).
• If an Active Hero is destroyed, the player must promote another controlled Hero.
• If a player controls no Heroes, they are eliminated.

--------------------------------------------------
CORRUPTION & FLIPPING
--------------------------------------------------

• Corruptible Heroes have a Corruption Limit.
• When the limit is reached, choose:
  1) Flip to corrupted side (remain under control, Shadow-aligned)
  2) Reject the Shadow (destroy Hero)

• Frodo cannot flip.
• Corrupted Heroes retain attachments unless otherwise specified.
• Default Corruption Limit: 3 (exceptions listed).

--------------------------------------------------
HEROES
--------------------------------------------------

========================
FELLOWSHIP / SHIRE
========================

Frodo Baggins  
Str 1 • HP 3  
Pickable • Not Corruptible  
Starting Region: The Shire  

Passive:  
• While bearing the One Ring, cannot be targeted from outside his region.

Reaction:  
• Discard 1 card to prevent 1 Corruption.

--------------------------------

Samwise Gamgee  
Str 1 • HP 4  
Supporting • Not Corruptible  
Starting Region: The Shire  

Passive (Once per round):  
• Prevent 1 Corruption to a Hero in this region.

Action (Exhaust):  
• Heal 1 Damage from a Hero in this region.

--------------------------------

Merry Brandybuck  
Str 2 • HP 3  
Supporting • Not Corruptible  
Starting Region: The Shire  

Passive:  
• If stacked with another Fellowship Hero, Allies here gain +1 Strength.

Reaction:  
• After Merry moves, draw 1 card.

--------------------------------

Pippin Took  
Str 1 • HP 3  
Supporting • Not Corruptible  
Starting Region: The Shire  

Passive:  
• The first Event played each round costs its controller +1 card.

Reaction (Once per round):  
• When an Event resolves in this region, draw 1 card.

========================
ELVES OF THE WEST
========================

Gandalf the Grey  
Str 2 • HP 5  
Pickable • Corruptible (Limit 3)  
Starting Region: Rivendell  

Passive:  
• The first Event each round costs 1 less card.

Action (Exhaust):  
• Heal 2 Damage from a Hero in this region.

-- CORRUPTED --
Gandalf the Fallen  
Str 4 • HP 5  

Passive:  
• Event cards cost +1 card to play.

Reaction:  
• When an Event resolves, add 1 Corruption to any region.

--------------------------------

Elrond, Lord of Rivendell  
Str 2 • HP 5  
Pickable • Not Corruptible  
Starting Region: Rivendell  

Passive:  
• Heroes in Rivendell cannot gain Corruption.

Action (Exhaust):  
• Heal 1 Damage from each Hero in this region.

--------------------------------

Galadriel  
Str 2 • HP 5  
Draw-only • Corruptible (Limit 7)  
Starting Region: Lothlórien  

Passive (Once per round):  
• Prevent 1 Corruption to a controlled region.

Action (Exhaust):  
• Draw 1 card.

-- CORRUPTED --
Galadriel, Lady of Shadow  
Str 7 • HP 6  

Passive:  
• Regions you control cannot remove Corruption.

========================
GONDOR
========================

Aragorn, Heir of Isildur  
Str 3 • HP 5  
Pickable • Corruptible (Limit 3)  
Starting Region: Gondor  

Passive:  
• Allies in this region gain +1 Strength.

Reaction:  
• After winning combat, may move to an adjacent region.

-- CORRUPTED --
Aragorn, King Unbound  
Str 5 • HP 6  

Passive:  
• Allies in controlled regions gain +1 Strength.

End of Round:  
• Add 1 Corruption to a region you control.

--------------------------------

Boromir, Captain of Gondor  
Str 4 • HP 4  
Pickable • Corruptible (Limit 3)  
Starting Region: Gondor  

Reaction:  
• When Boromir would be destroyed, prevent it and add 1 Corruption instead.

-- CORRUPTED --
Boromir, Driven by Need  
Str 5 • HP 4  

Passive:  
• Boromir cannot retreat.

Reaction:  
• When Boromir wins combat, gain control of one Ally in this region.

--------------------------------

Faramir, Captain of Ithilien  
Str 3 • HP 4  
Pickable • Not Corruptible  
Starting Region: Gondor  

Passive:  
• +1 Strength while defending Gondor.

Reaction:  
• After an Enemy enters this region, move 1 Ally here.

--------------------------------

Denethor, Steward of Gondor  
Str 2 • HP 5  
Draw-only • Corruptible (Limit 3)  
Starting Region: Gondor  

When Drawn:  
• If Gondor has Corruption, Denethor enters with 1 Corruption.

Passive:  
• Gondor cannot gain more than 1 Corruption per round.

Action (Exhaust):  
• Look at top 2 cards of the deck, discard 1, return 1.

-- CORRUPTED --
Denethor, Lord of Despair  
Str 4 • HP 4  

End of Round:  
• Add 1 Corruption to Gondor.

Reaction:  
• When an Ally in Gondor is destroyed, draw 1 card.

========================
ROHAN
========================

Théoden, King of Rohan  
Str 3 • HP 5  
Pickable • Corruptible (Limit 3)  
Starting Region: Rohan  

Passive:  
• Allies here gain +1 Strength.

Reaction:  
• When Théoden enters play, ready all Allies here.

-- CORRUPTED --
Théoden, King in Shadow  
Str 4 • HP 5  

End of Round:  
• If no combat occurred in Rohan this round, add 1 Corruption.

--------------------------------

Éomer  
Str 3 • HP 4  
Supporting • Not Corruptible  
Starting Region: Rohan  

Passive:  
• Allies stacked with Éomer gain +1 Strength while attacking.

Reaction:  
• After a Hero here is destroyed, ready Éomer and draw 1 card.

--------------------------------

Éowyn  
Str 3 • HP 4  
Supporting • Not Corruptible  
Starting Region: Rohan  

Passive:  
• +1 Strength while defending Rohan.

Reaction (Once per round):  
• Prevent 1 Damage to a Hero here from a stronger Enemy.

========================
DWARVES OF THE MOUNTAIN
========================

Gimli, Son of Glóin  
Str 4 • HP 5  
Pickable • Not Corruptible  
Starting Region: Erebor  

Passive:  
• Gains +1 Strength per Damage on him.

--------------------------------

Dáin Ironfoot  
Str 3 • HP 6  
Supporting • Not Corruptible  
Starting Region: Erebor  

Passive:  
• Erebor counts as controlled even if contested while Dáin is Active.

Action (Exhaust):  
• Prevent 1 Corruption in Erebor or an adjacent region.

--------------------------------

Thorin Stonehelm  
Str 4 • HP 5  
Supporting • Not Corruptible  
Starting Region: Erebor  

Passive:  
• Allies stacked with Thorin gain +1 Strength while defending.

Reaction:  
• After winning combat in Erebor, draw 1 card.

========================
WILD / NEUTRAL
========================

Treebeard  
Str 5 • HP 7  
Draw-only • Not Corruptible  
Starting Region: Fangorn  

Passive:  
• Treebeard cannot move unless an Enemy is present in Fangorn.

Reaction (Once per round):  
• When an Enemy enters Fangorn, deal 2 Damage to it.

Action (Exhaust):  
• Destroy a Lesser Location in Fangorn.

========================
ISENGARD / SHADOW
========================

Saruman the White  
Str 2 • HP 5  
Draw-only • Corruptible (Limit 3)  
Starting Region: Isengard  

When Drawn:  
• If Isengard has Corruption, Saruman enters corrupted.
• If Isengard is occupied, occupying player must retreat or fight.

This Round Only:  
• Saruman gains +2 Strength in Isengard.

End of Round (Uncontrolled):  
• Each player gains 1 Corruption.

Defeat:  
• Victor may destroy Saruman or take control of him.

-- CORRUPTED --
Saruman, Lord of Isengard  
Str 7 • HP 6  

Passive:  
• Enemies in this region gain +1 Strength.

End of Round:  
• Add 1 Corruption to each region adjacent to Isengard.

--------------------------------

Gríma Wormtongue  
Str 1 • HP 3  
Draw-only • Not Corruptible  
Starting Region: Isengard  

Passive:  
• Heroes in this region gain no benefits from Titles or Boons.

Reaction:  
• When a corruptible Hero gains Corruption here, add 1 additional Corruption.

Defeat:  
• When Gríma is destroyed, draw 1 card.

--------------------------------------------------
END OF CHARACTER_VALUES_CANON (LOCKED)
--------------------------------------------------
