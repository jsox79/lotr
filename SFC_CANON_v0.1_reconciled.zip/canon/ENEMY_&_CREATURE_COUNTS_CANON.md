## ENEMY_&_CREATURE_COUNTS_CANON
_Status: FINAL (v0.1 Playtest)_

Total Enemy & Creature cards: 34

Tier I — Common Enemies: 18
Tier II — Elite Enemies: 10
Tier III — Apex Enemies: 6

Enemy presence is designed to:
- apply constant pressure
- scale naturally
- enable Shadow victory without guaranteeing it
