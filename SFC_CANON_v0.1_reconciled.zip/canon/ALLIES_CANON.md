# ALLIES_CANON
_Status: LOCKED (v0.1 Playtest)_
_Total Allies: 18_

Allies are stack pieces that enhance Heroes. They do not act independently.
Rules text is resolved in the PWA.

## SHIRE (2)
- Shirefolk
- Hobbit Militia

## GONDOR (3)
- Citadel Guards
- Rangers of Ithilien
- Gondor Infantry

## ROHAN (3)
- Riders of Rohan
- Westfold Cavalry
- Éored Muster

## ELVES OF THE WEST (3)
- Lórien Wardens
- Rivendell Knights
- Woodland Archers

## DWARVES OF THE MOUNTAIN (2)
- Erebor Shieldwall
- Dwarven Axeguard

## ISENGARD / SHADOW (3)
- Isengard Laborers
- Orc Warband
- Uruk Warhost

## FANGORN / WILD (2)
- Fangorn Ents
- Huorns

END OF ALLIES_CANON (LOCKED)
