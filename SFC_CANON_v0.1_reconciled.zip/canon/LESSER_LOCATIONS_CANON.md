# LESSER_LOCATIONS_CANON
_Status: FINAL_
_Last updated: current session_

This document defines all Lesser Location cards,
their effects, and their persistence rules.

Lesser Locations attach to Greater Regions.
They do not count toward victory but strongly influence play.

Unless otherwise specified, Lesser Locations remain in play
until destroyed by a card effect.

---

## DESIGN PRINCIPLES

- Lesser Locations change how a region *feels*
- They introduce local rules, not global ones
- They create incentives to fight, flee, or endure
- Most are persistent; a few are intentionally temporary

---

## CORE LESSER LOCATIONS

### 🏰 City Under Siege
Location — Lesser (Persistent)

While this location is in play:
- Characters in this region take 1 additional Damage during combat.

At the end of each round:
- Add 1 Corruption to this region.

*Walls fall long before hearts do.*

---

### 🌿 Elven Refuge
Location — Lesser (Persistent)

- Heroes in this region gain +1 Health.

At the end of each round:
- Remove 1 Corruption from this region.

*Light yet lingers.*

---

### 🔥 Orc Encampment
Location — Lesser (Persistent)

- Enemy characters in this region gain +1 Strength.

When this location enters play:
- Add 1 Corruption to this region.

---

### 🕯️ Beacon Lit
Location — Lesser (Persistent)

While you control this region:
- Allies here gain +1 Strength.

If this location is destroyed:
- Add 1 Corruption to this region.

*Hope is visible — and vulnerable.*

---

### 🪨 Ancient Ruins
Location — Lesser (Persistent)

When a character enters this region:
- Its controller draws 1 card.
- That character gains 1 Corruption.

*Knowledge never lies dormant.*

---

### 🌑 Shadow Creeps
Location — Lesser (Persistent)

- Heroes in this region cannot remove Corruption by card effects.

---

## ADDITIONAL CANON LOCATIONS

### 🌪️ Roads Fallen Silent
Location — Lesser (Temporary)

- Characters may not move out of this region during the Journey Phase.

At the end of the round:
- Destroy this location.

*The way forward is lost — for now.*

---

### ⚔️ Fractured Allegiance
Location — Lesser (Persistent)

- Allies in this region lose all faction-based bonuses.

When this location is destroyed:
- Draw 1 card.

*Old loyalties strain under new fears.*

---

### 🌲 Wild Growth
Location — Lesser (Persistent)

- All characters in this region lose 1 Strength (minimum 1).
- This region cannot gain Corruption from Event cards.

*The land resists all masters.*

---

### 🔥 Smoldering Ruins
Location — Lesser (Persistent)

When this location enters play:
- Destroy one Ally in this region.

At the end of each round:
- Add 1 Corruption to this region.

*Nothing remains but memory and ash.*

---

### 🕯️ Hidden Paths
Location — Lesser (Persistent)

Once per round:
- A Hero in this region may move to any adjacent region
  ignoring Enemy presence.

*Not all roads are known.*

---

## RECOMMENDED DECK INCLUSION (GUIDELINE)

Suggested Universal Deck presence:
- 10–12 Lesser Location cards total
- Duplicate high-impact locations as needed
- Avoid flooding the board; regions should feel distinct

---

## DESIGN NORTH STAR

A Lesser Location should make players say:
> “This place has changed — we can’t ignore it.”

If a Lesser Location is ignored, it failed.
If it ends the game alone, it failed.

---

END OF LESSER_LOCATIONS_CANON (FINAL)
